# Biljart spel

Student 1 naam: Joël Maatkamp  
Student 1 id  : 14594722  
Student 2 naam: Kaai Hoffmann  
Student 2 id  : 14050714

## Belangerijkste aanpassingen
- Er zijn zeven handgemaakte shaders toegevoegd:
  - Phong
  - Cartoon
  - Lava
  - Force field
  - Galaxy
  - TableWood
  - TableCloth
- Er is een physics engine geimplementeerd die toestaat dat ballen van elkaar afkaatsen en op de tafel blijven.
- Er is een systeem geimplementeerd om de 'witte' bal te kaatsen, gebruik de pijltjes toetsen om te draaien en de 
  kracht te verhogen of te verlagen. Gebruik spatie om te kaatsen.
- Er is geluid toegevoegd.